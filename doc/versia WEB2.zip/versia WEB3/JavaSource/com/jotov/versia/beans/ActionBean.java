package com.jotov.versia.beans;

import com.jotov.versia.orml.Actions;

public class ActionBean extends Actions {

	public ActionBean() {
		super();
	}

}
