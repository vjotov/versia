package com.jotov.versia.beans;

import javax.persistence.EntityManager;

public interface iExecuteQuery {

	String executeQuery();

	void setEntityManager(EntityManager em);

	void resetEntityManager();

}
