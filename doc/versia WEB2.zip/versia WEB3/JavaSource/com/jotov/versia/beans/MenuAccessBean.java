package com.jotov.versia.beans;

public class MenuAccessBean {
	public MenuAccessBean() {}
	public boolean getMenuAccess(String menu_code){
		return true;
	}
}
