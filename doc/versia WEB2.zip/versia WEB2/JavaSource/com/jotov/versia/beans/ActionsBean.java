package com.jotov.versia.beans;

import java.util.ArrayList;
import java.util.Set;
import javax.annotation.PostConstruct;
import javax.faces.event.ActionEvent;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.jotov.versia.orml.Actions;

public class ActionsBean {
	private ArrayList<Actions> actions = new ArrayList<Actions>();
	private Actions selectedAction;
	private Set<Integer> rowsToUpdate;
	private EntityManagerFactory factory;
	private EntityManager em;

	public ActionsBean() {

	}

	@SuppressWarnings("unchecked")
	@PostConstruct
	public void init() {
		factory = Persistence.createEntityManagerFactory("versia_er3");
		try {
			em = factory.createEntityManager();
			Query query = em.createQuery("select a from Actions a ");
			ArrayList<Actions> result = (ArrayList<Actions>) query
					.getResultList();
			//assert false : result.size();
			this.actions.addAll(result);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

	public void updateAction(ActionEvent event) {
		int index = actions.indexOf(selectedAction);
		rowsToUpdate.add(index);
	}

	@Override
	protected void finalize() throws Throwable {
		factory.close();
		super.finalize();
	}

	public ArrayList<Actions> getActions() {
		return actions;
	}

	public void setActions(ArrayList<Actions> actions) {
		this.actions = actions;
	}

	public Actions getSelectedAction() {
		return selectedAction;
	}

	public void setSelectedAction(Actions selectedAction) {
		this.selectedAction = selectedAction;
	}

	public Set<Integer> getRowsToUpdate() {
		return rowsToUpdate;
	}

}
