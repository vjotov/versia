package com.jotov.versia.beans;

import java.util.ArrayList;

import javax.persistence.EntityTransaction;

import com.jotov.versia.orm.VObject;
import com.jotov.versia.orm.VObjectVersion;

public class EditVObjectBean extends aDBbean {
	// private VObject vo;
	private String NewName;
	private String NewData;
	private Boolean isWorkItem;
	private UserSessionBean session;

	@Override
	public String executeQuery(int mode) {
		switch (mode) {
		case 1:
			return createNewVersion();
			// case 2:
			// return newProduct();
			// case 3:
			// return saveProduct();
		default:
			return null;
		}
	}

	private String createNewVersion() {
		EntityTransaction trx = em.getTransaction();
		trx.begin();
		VObjectVersion oldVer = session.getSelectedVersion();
		VObject vo = oldVer.getVobject();
		if (!oldVer.getObjectName().equals(NewName)
				|| !oldVer.getObjectDatum().equals(NewData)) {
			ArrayList<VObjectVersion> precedors = new ArrayList<VObjectVersion>();
			precedors.add(oldVer);

			VObjectVersion nv = VObjectVersion.createVersion(vo, NewName,
					NewData, session.getWorkspace(), precedors,
					session.getUserProfile());

			vo.setWorkItem(isWorkItem);
			oldVer.setWorkspace(null);
			em.persist(nv);
			em.persist(oldVer);
		}
		if (vo.isWorkItem() != this.isWorkItem) {
			vo.setWorkItem(isWorkItem);
			em.persist(vo);
		}

		trx.commit();
		return null;
	}

	public void Save() {
		System.out.println("editVObjectBean.Save()/0");
		dbean.executeQuery(this, 1);
		session.setSelectedVersion(null);
		isWorkItem = null;
		NewData = null;
		NewName = null;
	}

	public Integer getVObjectID() {
		VObjectVersion vov = session.getSelectedVersion();
		if (vov == null)
			return null;
		else {
			VObject vo = vov.getVobject();
			return vo.getVObjectId();
		}
	}

	public String getVObjectName() {
		if (NewName == null && session.getSelectedVersion() != null)
			NewName = session.getSelectedVersion().getObjectName();

		return NewName;
	}

	public void setVObjectName(String newName) {
		this.NewName = newName;
	}

	public String getVObjectDatum() {
		if (NewData == null && session.getSelectedVersion() != null)
			NewData = session.getSelectedVersion().getObjectDatum();

		return NewData;
	}

	public void setVObjectDatum(String newDatum) {
		this.NewData = newDatum;
	}

	public Integer getVObjectVersion() {
		VObjectVersion vov = session.getSelectedVersion();
		if (vov == null)
			return null;
		else
			return vov.getVersionNumber();
	}

	public UserSessionBean getSession() {
		return session;
	}

	public void setSession(UserSessionBean session) {
		this.session = session;
	}

	public boolean getIsWorkItem() {
		if (isWorkItem == null && session.getSelectedVersion() != null)
			isWorkItem = new Boolean(session.getSelectedVersion().getVobject()
					.isWorkItem());
		else if (isWorkItem == null)
			return false;
		return isWorkItem;
	}

	public void setIsWorkItem(boolean isWorkItem) {
		this.isWorkItem = isWorkItem;
	}

}
