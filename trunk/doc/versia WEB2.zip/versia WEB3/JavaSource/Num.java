public class Num {
	int number;

	public Num() {
	}

	public Num(int i) {
		number = i;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

}
