package com.jotov.versia.beans;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;
import com.jotov.versia.orml.Actions;

public class ActionsBean extends aDBbean {
	private ArrayList<Actions> actions;

	// private Actions selectedAction;

	public ActionsBean() {

	}

	public ArrayList<Actions> getActions() {
		if (actions == null) {
			System.out.println("getActions - init");
			actions = new ArrayList<Actions>();
			dbean.executeQuery(this);
		}
		return actions;
	}

	public void setActions(ArrayList<Actions> actions) {
		this.actions = actions;
	}

	/*
	 * public Actions getSelectedAction() { return selectedAction; }
	 * 
	 * public void setSelectedAction(Actions selectedAction) {
	 * this.selectedAction = selectedAction; }
	 */

	@SuppressWarnings("unchecked")
	@Override
	public String executeQuery() {
		Query query = em.createQuery("select a from Actions a");
		List<Actions> result = query.getResultList();
		actions.addAll(result);

		return null;
	}

}
