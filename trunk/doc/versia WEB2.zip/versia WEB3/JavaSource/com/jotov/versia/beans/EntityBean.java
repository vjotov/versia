package com.jotov.versia.beans;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EntityBean {
	private EntityManagerFactory factory;
	private EntityManager em;

	public EntityBean() {
		System.out.println("EntityBean constructor start");
		if (factory == null) {
			factory = Persistence.createEntityManagerFactory("versia_er3");
			em = factory.createEntityManager();
		}
		System.out.println("EntityBean constructor end");
	}
	
	public EntityManager getEntityManager() {
		System.out.println("EntityBean getEntityManager ");
		return em;
	}
	
	@Override
	protected void finalize() throws Throwable {
		factory.close();
		super.finalize();
	}
	
}
