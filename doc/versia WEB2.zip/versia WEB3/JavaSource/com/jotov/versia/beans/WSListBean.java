package com.jotov.versia.beans;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;

import com.jotov.versia.orm.Release;
import com.jotov.versia.orm.WSpace;

public class WSListBean extends aDBbean {
	private List<WSpace> workspaces = new ArrayList<WSpace>();
	private WSpace mainWorkspace;
	private UserSessionBean session;

	public WSListBean() {
	}

	@Override
	public String executeQuery(int mode) {
		switch (mode) {
		case 1:
			return loadWorspaces();
		default:
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	private String loadWorspaces() {
		if (session.getRelease() != null) {
			Query query = em
					.createQuery("select w from WSpace w where w.release=:rel");
			query.setParameter("rel", session.getRelease());
			List<WSpace> result = query.getResultList();
			workspaces.addAll(result);
		}
		return null;
	}

	public List<WSpace> getWorkspaces() {
		//dbean.executeQuery(this, 1);
		Release s = session.getRelease();
		workspaces.addAll(s.getWorkspaces());
		return workspaces;
	}

	public void setWorkspaces(List<WSpace> workspaces) {
		this.workspaces = workspaces;
	}

	public UserSessionBean getSession() {
		return session;
	}

	public void setSession(UserSessionBean session) {
		this.session = session;
	}

	public WSpace getMainWorkspace() {
		mainWorkspace = session.getRelease().getMasterWorkspace();
		return mainWorkspace;
	}

}
