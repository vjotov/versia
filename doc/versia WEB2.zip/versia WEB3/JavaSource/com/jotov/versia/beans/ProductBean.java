package com.jotov.versia.beans;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import com.jotov.versia.orm.Product;

public class ProductBean extends aDBbean {
	private ArrayList<Product> products = null;
	private Product selectedProduct = null;
	private String newProductName;
	private UserSessionBean session;

	@Override
	public String executeQuery(int mode) {
		switch (mode) {
		case 1:
			return loadProducts();
		case 2:
			return newProduct();
		case 3:
			return saveProduct();
		default:
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	private String loadProducts() {
		Query query = em.createQuery("select p from Product p");
		List<Product> result = query.getResultList();
		products.addAll(result);

		return null;
	}

	private String newProduct() {
		EntityTransaction trx = em.getTransaction();
		trx.begin();
		//TODO
		List<Object> listForPersist = Product.createProduct(newProductName);
		for(Object obj: listForPersist){
			em.persist(obj);
		}		
		trx.commit();

		newProductName = new String();
		session.doOpenProduct();
		return null;
	}

	private String saveProduct() {
		EntityTransaction trx = em.getTransaction();
		trx.begin();
		em.persist(selectedProduct);
		trx.commit();

		return null;
	}

	public void createProduct() {
		dbean.executeQuery(this, 2);
	}

	public void updateProduct() {
		dbean.executeQuery(this, 3);
	}

	public void openProduct() {
		session.setOpenedProduct(selectedProduct);
		session.doOpenReleases();
	}

	// GETTERS & SETTERS

	public ArrayList<Product> getProducts() {
		products = new ArrayList<Product>();
		dbean.executeQuery(this, 1);
		return products;
	}

	public void setProducts(ArrayList<Product> products) {
		this.products = products;
	}

	public String getNewProductName() {
		return newProductName;
	}

	public void setNewProductName(String newProductName) {
		this.newProductName = newProductName;
	}

	public Product getSelectedProduct() {
		return selectedProduct;
	}

	public void setSelectedProduct(Product selectedProduct) {
		this.selectedProduct = selectedProduct;
	}

	public UserSessionBean getSession() {
		return session;
	}

	public void setSession(UserSessionBean session) {
		this.session = session;
	}
}
