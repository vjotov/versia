package com.jotov.versia.beans;

import javax.persistence.EntityManager;

public abstract class aDBbean implements iExecuteQuery {

	protected EntityManager em;

	public aDBbean() {
		super();
	}

	@Override
	public void setEntityManager(EntityManager em) {
		this.em = em;
		
	}

	@Override
	public void resetEntityManager() {
		em = null;
		
	}

}