package com.jotov.versia.beans;

public class TitleBean {

	private String project = "na";
	private String worlspace = "na";
	public TitleBean() {
		// TODO Auto-generated constructor stub
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getWorlspace() {
		return worlspace;
	}
	public void setWorlspace(String worlspace) {
		this.worlspace = worlspace;
	}

}
