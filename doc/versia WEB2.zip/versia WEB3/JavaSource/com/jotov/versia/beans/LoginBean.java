package com.jotov.versia.beans;

public class LoginBean extends aDBbean {
	private String name;
	private String password;

	public LoginBean() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String CheckValidUser() {
		return dbean.executeQuery(this);
	}

	@Override
	public String executeQuery() {
		String return_srt;
		// Query query = em
		// .createQuery("select up from UserProfile up where up.userName = '"
		// + this.name
		// + "' and up.password = '"
		// + this.password
		// + "' ");
		// if (query.getResultList().size() == 1)
		return_srt = "success";
		// else
		// return_srt = "fail";
		return return_srt;
	}
}
