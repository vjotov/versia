package com.jotov.versia.beans;

import javax.persistence.Query;

public class LoginBean extends aDBbean {
	private String name;
	private String password;

	// private DBConnectBean dbean;

	public LoginBean() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String CheckValidUser() {
		return dbean.executeQuery(this);
		/*
		 * String return_srt; EntityManagerFactory factory = Persistence
		 * .createEntityManagerFactory("versia_er3"); try { em =
		 * factory.createEntityManager();
		 * 
		 * return_srt = executeQuery();
		 * 
		 * } catch (Exception ex) { System.out.println("LoginBean 0 " +
		 * ex.getMessage() + " / "+ex.getClass()); return_srt = "fail"; }
		 * finally { factory.close(); } return return_srt;//
		 */
	}

	@Override
	public String executeQuery() {
		String return_srt;
		Query query = em
				.createQuery("select up from UserProfile up where up.userName = '"
						+ this.name
						+ "' and up.password = '"
						+ this.password
						+ "' ");
		if (query.getResultList().size() == 1)
			return_srt = "success";
		else
			return_srt = "fail";
		return return_srt;
	}

	/*
	 * public DBConnectBean getDbean() { return dbean; }
	 * 
	 * public void setDbean(DBConnectBean dbean) { this.dbean = dbean; }
	 */
}
