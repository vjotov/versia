package com.jotov.versia.beans.vobj;

public enum VisibilityEnum {
	LOCAL, 
	PARENT, 
	RELEASE, 
	OTHER
}
