package com.jotov.versia.beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.jotov.versia.orm.Release;
import com.jotov.versia.orm.WSpace;

public class WSListBean extends aDBbean {
	private UserSessionBean session;
	private List<WSpace> workspaces = new ArrayList<WSpace>();
	private WSpace mainWorkspace;
	private int selectedRow;

	public WSListBean() {
	}

	@Override
	public String executeQuery(int mode) {
		switch (mode) {
		case 1:
			return loadWorspaces();
		case 2:
			return createOffspringWorkspace();
		case 3:
			return saveWorkspace();
		default:
			return null;
		}
	}

	private String createOffspringWorkspace() {
		EntityTransaction trx = em.getTransaction();
		trx.begin();
		WSpace selectedWorkspace = this.workspaces.get(selectedRow);
		WSpace newOffspring = WSpace.createWorkspace("New Workspace",
				selectedWorkspace, null);
		em.persist(newOffspring);
		trx.commit();

		// TODO Auto-generated method stub
		return null;
	}

	private String saveWorkspace() {
		EntityTransaction trx = em.getTransaction();
		trx.begin();
		WSpace selectedWorkspace = this.workspaces.get(selectedRow);
		em.persist(selectedWorkspace);
		em.refresh(session.getRelease());
		trx.commit();

		return null;
	}

	public void updateWorkspace() {
		dbean.executeQuery(this, 3);
	}

	public void creareOffspring() {
		dbean.executeQuery(this, 2);
	}

	@SuppressWarnings("unchecked")
	private String loadWorspaces() {

		if (session.getRelease() != null) {
			Query query = em
					.createQuery("select w from WSpace w where w.release=:rel");
			query.setParameter("rel", session.getRelease());
			List<WSpace> result = query.getResultList();
			workspaces.addAll(result);
		}
		return null;
	}

	public List<WSpace> getWorkspaces() {
		// dbean.executeQuery(this, 1);
		workspaces.clear();
		Release s = session.getRelease();
		workspaces.addAll(s.getWorkspaces());
		return workspaces;
	}

	public void setWorkspaces(List<WSpace> workspaces) {
		this.workspaces = workspaces;
	}

	public UserSessionBean getSession() {
		return session;
	}

	public void setSession(UserSessionBean session) {
		this.session = session;
	}

	public WSpace getMainWorkspace() {
		mainWorkspace = session.getRelease().getMasterWorkspace();
		return mainWorkspace;
	}

	public Integer getSelectedRow() {
		return selectedRow;
	}

	public void setSelectedRow(int selectedRow) {
		this.selectedRow = selectedRow;
	}

}
