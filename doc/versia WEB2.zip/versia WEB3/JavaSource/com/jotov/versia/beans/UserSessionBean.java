package com.jotov.versia.beans;

import com.jotov.versia.orm.Product;
import com.jotov.versia.orm.UserProfile;

public class UserSessionBean {
	private UserProfile userProfile;
	private String currentPage = "/pages/00_welcome.xhtml";
	private Product product;

	public UserSessionBean() {
	}

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	// /////////////////////////////////////////
	public void doNewProduct() {
		setCurrentPage("/pages/03_new_product.xhtml");
	}

	public void doOpenProduct() {
		setCurrentPage("/pages/04_open_product.xhtml");
	}

	public void doCloseProduct() {
		// TODO - close product
		setCurrentPage("/pages/00_welcome.xhtml");
	}

	public void doOpenReleases() {
		// TODO Auto-generated method stub
		setCurrentPage("/pages/00_welcome.xhtml");
	}

	public void doManageActions() {
		setCurrentPage("/pages/01_manage_actions.xhtml");
	}

	public void doManageUsers() {
		setCurrentPage("/pages/02_manage_users.xhtml");
	}

	public void doHelpAbout() {
		setCurrentPage("/pages/00_welcome.xhtml");
	}

	public void doManageActiveWorkItem() {
	}

	public void doMakeWorkItem() {
	}

	public void doViewDistribution() {
	}

	public void doShowHelp() {
		setCurrentPage("/pages/00_welcome.xhtml");
	}

	public void setOpenedProduct(Product selectedProduct) {
		setProduct(selectedProduct);

	}

	// GETTERS & SETTERS
	public void setProduct(Product product) {
		this.product = product;
	}

	public Product getProduct() {
		return product;
	}

}
