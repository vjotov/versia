package com.jotov.versia.beans;

import com.jotov.versia.orm.Product;
import com.jotov.versia.orm.Release;
import com.jotov.versia.orm.UserProfile;

public class UserSessionBean {
	private UserProfile userProfile;
	private String currentPage = "/pages/00_welcome.xhtml";
	private Product product;
	private Release release;

	public UserSessionBean() {
	}

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	///////////////////////////////////////////
	public String closeProduct() {
		this.setProduct(null);
		return "open_product";
	}

	public String closeRelease() {
		this.setRelease(null);
		return "open_release";
	}
	
	public String closeWorkspace() {
		//TODO - to close workspace;
		return "open_workspace";
	}
	
	//##############################################
	
	public void doOpenProduct() {
		setCurrentPage("/pages/03_open_product.xhtml");
	}

	

	public void doOpenReleases() {
		setCurrentPage("/pages/04_open_release.xhtml");
	}

	public void doOpenWorkspace() {
		setCurrentPage("/pages/05_open_ws.xhtml");
	}

	public void doManageActions() {
		setCurrentPage("/pages/01_manage_actions.xhtml");
	}

	public void doManageUsers() {
		setCurrentPage("/pages/02_manage_users.xhtml");
	}

	public void doHelpAbout() {
		setCurrentPage("/pages/00_welcome.xhtml");
	}

	public void doManageActiveWorkItem() {
	}

	public void doMakeWorkItem() {
	}

	public void doViewDistribution() {
	}

	public void doShowHelp() {
		setCurrentPage("/pages/00_welcome.xhtml");
	}

	// GETTERS & SETTERS
	public void setProduct(Product product) {
		this.product = product;
	}

	public Product getProduct() {
		return product;
	}

	public void setRelease(Release release) {
		this.release = release;
	}

	public Release getRelease() {
		return this.release;
	}

}
